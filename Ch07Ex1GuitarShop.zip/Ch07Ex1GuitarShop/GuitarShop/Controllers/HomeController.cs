﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace GuitarShop.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() //action method for Index
        {
            return View(); //display Index page
        }

        [Route("[action]")]
        public IActionResult About() //action method for About
        {
            return View(); //display About page
        }

        [Route("[action]")]
        public IActionResult ContactUs() //action method for ContactUs
        {
            Dictionary<string, string> contact = new Dictionary<string, string> //create new dictionary model
            {
                {"Phone" , "555-123-4567" },
                {"Email", "info@myguitarshop.com"},
                {"Address", "820 N University Parkway" }
            };
            return View(contact); //display CountactUs
        }
    }
}
