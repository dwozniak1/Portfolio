﻿using System.ComponentModel.DataAnnotations;

namespace GuitarShop.Models
{
    public class Category
    {
        public int CategoryID { get; set; }

        [Required(ErrorMessage = "Please enter a category name.")]
        [StringLength(20, ErrorMessage ="Category must be less than 20 letters.")]
        public string Name { get; set; } = string.Empty;
    }
}
