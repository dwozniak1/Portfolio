﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;  // for NotMapped

namespace Bookstore.Models
{
    public class User : IdentityUser
    {
        [NotMapped]
        public IList<string> RoleNames { get; set; } = null!;

        [Display(Name = "First Name" )]
        [StringLength(255)]
        public string? FirstName { get; set; } = "";

        [Display(Name = "Last Name")]
        [StringLength(255)]
        public string? LastName { get; set; } = "";
    }
}
