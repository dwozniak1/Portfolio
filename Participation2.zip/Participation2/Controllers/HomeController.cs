﻿using Microsoft.AspNetCore.Mvc;
using Participation2.Models;
using System.Diagnostics;

namespace Participation2.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Name = "Mary";
            ViewBag.FV = 99999.99;
            return View();
        }
        [HttpPost]
        public IActionResult Index (FutureModel model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.FV = model.CalculateFutureValue();
            }
            else
            {
                ViewBag.FV = 0;
            }
            return View();
        }

    }
}